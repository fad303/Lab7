package Commands;

import Classes.Worker;
import Instruments.DBHandler;
import Instruments.ScriptInfo;
import Instruments.UserCommandsScript;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Vector;

public class Execute_Script implements Serializable {
    private String sFile;
    private transient Vector<Worker> workers;
    private ArrayList<String> history;
    private transient LocalDateTime today;
    private transient BufferedReader reader;
    private transient ArrayList<String> scripts;
    private ArrayList<String> scriptCommands;
    private String info;
    private transient DBHandler db;
    private String creater;

    public String getInfo() {
        if (info.equalsIgnoreCase("")) return "Скрипт не содержит команд";
        return this.info;
    }

    public ArrayList<String> getScriptCommands() {
        return this.scriptCommands;
    }

    public void setFields(Vector<Worker> workers, LocalDateTime today, DBHandler db) {
        this.workers = workers;
        this.today = today;
        this.db = db;
    }

    public void setUserId(String userId) {
        this.creater = userId;
    }

    public void setScripts(ArrayList<String> scripts) {
        this.scripts = scripts;
    }

    public Execute_Script () {}

    public Execute_Script (String sFile, Vector<Worker> workers, ArrayList<String> history, LocalDateTime today,
                           BufferedReader reader, File file, ArrayList<String> scripts) {
        this.sFile = sFile;
        this.workers = workers;
        this.history = history;
        this.today = today;
        this.reader = reader;
        this.scripts = scripts;
    }

    public Execute_Script(String sFile, ArrayList<String> history) {
        this.history = history;
        this.sFile = sFile;
    }

    public Execute_Script(String sFile) {
        this.sFile = sFile;
    }

    public void setCreater(String creater) {
        this.creater = creater;
    }

    public void getCommandsFromFile() {
        File script = new File(sFile);
        scriptCommands = Instruments.Processing.scriptToString(script, scripts);
    }

    public void execute() {
        String userCommand;
        for (int i = 0; i<scriptCommands.size(); i++) {
            userCommand = scriptCommands.get(i);
            UserCommandsScript.check(userCommand);
            if (UserCommandsScript.getStatus() == 1) {
                try {
                    UserCommandsScript.execute(userCommand, reader, workers, today, history, scriptCommands, i, db, creater);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (userCommand.equalsIgnoreCase("add")) i += 10;
                try {
                    if (userCommand.substring(0, 6).equalsIgnoreCase("update") && UserCommandsScript.getStatus() == 1)
                        i += 10;
                } catch (Exception e) {
                }
            }
        }
        info = ScriptInfo.getInfo();
    }

    public String toStrings() {
        return "execute_script " + sFile;
    }
}
