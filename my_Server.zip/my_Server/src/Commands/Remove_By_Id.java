package Commands;

import Classes.Worker;
import Instruments.DBHandler;

import java.io.Serializable;
import java.util.Vector;

public class Remove_By_Id implements Serializable {
    private transient Vector<Worker> workers;
    private Long id;
    private String info;
    private transient DBHandler db;
    private String creater;

   public Remove_By_Id () {
       this.info = null;
   }

    public Remove_By_Id(Vector<Worker> workers, Long id) {
        this.workers = workers;
        this.id = id;
    }

    public Remove_By_Id(Vector<Worker> workers, Long id, DBHandler db) {
        this.workers = workers;
        this.id = id;
        this.db = db;
    }

    public Remove_By_Id(long id) {
        this.id = id;
    }

    public void setUserId(String creater) {
        this.creater = creater;
    }

    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers, DBHandler db) {
       this.workers = workers;
       this.db = db;
    }

    public void execute() {
        int rows = db.executeUpdate("DELETE FROM workers WHERE id = " + id + " and creater = '" + creater+"'");// + " and creater = " + userId);
        if (rows == 0){
            info = "Элемента с данным id либо не существует в коллекции, либо он принадлежит не вам";
        }
        else {
            try {
                workers.stream().filter(f -> f.getId().toString().equalsIgnoreCase(id.toString())).limit(1).forEach(f -> workers.remove(f));
            } catch (Exception e) {
            }
            info = "Элемент успешно удален";
            workers = null;
            id = null;
        }
    }
    public String toStrings() {
        return "remove_by_id " + id;
    }
}
