package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Vector;

public class Info implements Serializable {

    private transient Vector<Worker> workers;
    private transient LocalDateTime today;
    private String info;

    public Info() {}

    public Info (Vector<Worker> workers, LocalDateTime today) {
        this.workers = workers;
        this.today = today;
    }

    public String getInfo() {
        return this.info;
    }

    public void execute() {
        info = "Тип коллекции: Vector<Worker>\n";
        try {
            info = info + "Количество элементов коллекции " + workers.size() + "\n";
        } catch (Exception e) {
            info = info + "Коллекция содержит 0 элементов\n";
        }
        info = info +"Инициализирована "+ today.toString();
        workers = null;
        today = null;
    }

    @Override
    public String toString() {
        return "info";
    }
}
