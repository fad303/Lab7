package Commands;

import Classes.*;
import Instruments.DBHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class Update implements Serializable {
    private transient Vector<Worker> workers;
    private transient Worker worker;
    private String info;
    private String name;
    private int salary;
    private LocalDateTime endDate;
    private Double x;
    private Float y;
    private Coordinates coordinates;
    private Position position;
    private Status status;
    private Organization organization;
    private String fullName;
    private long employeesCount;
    private OrganizationType type;
    private Long id;
    private LocalDate creationDate;
    private transient DBHandler db;
    private String creater;

    public Update(Long id) {
        this.info = null;
        this.id = id;
    }

    public Update() {
        this.info = null;
    }

    public Update (Vector<Worker> workers, Long id) {
        this.workers = workers;
        this.id = id;
        this.info = null;
    }

    public Update (Vector<Worker> workers, Long id,  DBHandler db) {
        this.workers = workers;
        this.id = id;
        this.info = null;
        this.db = db;
    }

    public void setUserId(String userId) {
        this.creater = userId;
    }

    public void setWorkers(Vector<Worker> workers, DBHandler db) {
        this.workers = workers;
        this.db = db;
    }

    public String getInfo() {
        return this.info;
    }

    public String getName() {
        return this.name;
    }

    public void execute() {
        if (workers != null) {
            for (Worker f : workers) {
                if (f.getId().toString().equalsIgnoreCase(id.toString())) {
                    worker = f;
                    break;
                }
            }
        }
        if (worker==null) info = "Элемента с данным id не существует";
        else {

            if (db.executeUpdate("UPDATE workers SET \"orgEmpCount\"= "+employeesCount+", \"name\" = '"+name+"'," +
                    " \"orgFullName\" = '"+fullName+"', " + "status = '"+status+"', \"position\" = '"+position+"'," +
                    " \"organizationType\" = '"+type+"', " + "\"corX\" = "+x+", \"corY\" = "+y+", " +
                    "salary = "+salary+", cd_day = "+creationDate.getDayOfMonth()+", cd_month = "+creationDate.getMonthValue()+", " +
                    "cd_year = "+creationDate.getYear()%100+", ed_day ="+endDate.getDayOfMonth()+", ed_month = "+endDate.getMonthValue()+
                    ", ed_year = "+endDate.getYear()%100+", creater = '"+creater+"', ed_hour = "+endDate.getHour()+
                    ", ed_min = "+endDate.getMinute()+", ed_sec = "+endDate.getSecond()+" WHERE id = "+id) == -1) {
                info = "Сбой обновления элемента";
            }
            else {
                workers.clear();
                db.getData(workers, "SELECT * FROM workers;");
                info = "Элемент обновлен";
                workers = null;
                worker = null;
            }
        }
    }

    public void check() {
        int control = 0;
        if (workers != null) {
            for (Worker f : workers) {
                if (f.getId().toString().equalsIgnoreCase(id.toString())) {
                    control = 1;
                    worker = f;
                    break;
                }
            }
        }
        if (control == 0) {
            info = "Элемента с данным id не существует";
        } else if (!creater.equals(worker.getUserId())) {
            info = "Невозможно обновить: Элемент с данным id не принадлежит вам";
        } else {
            name = worker.getName(); x = worker.getCoordinates().getX();
            y = worker.getCoordinates().getY(); salary = worker.getSalary();
            endDate = worker.getEndDate(); creationDate = worker.getCreationDate();
            position = worker.getPosition(); status = worker.getStatus();
            fullName = worker.getOrganization().getFullName(); employeesCount = worker.getOrganization().getEmployeesCount();
            type = worker.getOrganization().getType();
            worker = null; workers = new Vector<>();
            info = "+";
        }
    }

    public int fieldsUpdate() throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String result;
        String name = null;
        Integer salary = 0;
        LocalDateTime endDate = null;
        Double x = null;
        Float y = null;
        Status status = null;
        Position position = null;
        String fullName = null;
        long employeesCount = -1;
        OrganizationType type = null;
        LocalDate creationDate = LocalDate.now();

        int control = 0;
        while (control==0) {
            System.out.print("Name (" + this.name + "): ");
            result = reader.readLine();
            if (result.equalsIgnoreCase("null")) {
                System.out.println("Ошибка: поле \"name\" содержит null");
            } else if (result.equalsIgnoreCase("")) {
                System.out.println("Ошибка: поле \"name\" не может быть пустым");
            } else if (result.equalsIgnoreCase("-")) {
                name = this.name; control++;
            } else { name = result; control++; }
        }


        control = 0;
        while (control==0) {
            System.out.print("Введите salary (" + this.salary + "): ");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"salary\" содержит null");
                } else if (result.equalsIgnoreCase("-")) {
                    salary = this.salary;
                    control++;
                }
                else {
                    salary = Integer.parseInt(result);
                    if (salary <= 0) {
                        System.out.println("Ошибка: поле \"salary\" должно быть больше 0");
                    }
                    else control++;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: поле \"salary\" должно быть целым числом.");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }

        control = 0;
        while (control==0){
            System.out.println("Введите end date");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    endDate = null;
                } else {
                    endDate = LocalDateTime.parse(result, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
                    control++;
                }
            }catch(Exception e){
                System.out.println("Поле endDate введено некорректно (dd.MM.yy HH:mm:ss)");
            }
        }

        System.out.println("Coordinates:");

        control = 0;
        while (control==0) {
            System.out.print("Введите x (" + this.x + "): ");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка: поле \"x\" содержит null");
                } else if (result.equalsIgnoreCase("-")) {
                    x = this.x; control++;
                } else {
                    x = Double.parseDouble(result);
                    control++;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: \"x\" не является целым числом");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }


        control = 0;
            while (control==0) {
                System.out.print("Введите y (" + this.y + "): ");
                try {
                    result = reader.readLine();
                    if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                        System.out.println("Ошибка: поле \"y\" содержит null");
                    } else if (result.equalsIgnoreCase("-")) {
                        y = this.y; control++;
                    } else {
                        y = Float.parseFloat(result);
                        if (y >= 77) {
                            System.out.println("Ошибка: поле \"y\" должно быть меньше 77");
                        }
                        else {
                            control++;
                        }
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Ошибка: поле \"y\" не является целым числом");
                } catch (IOException e) {
                    System.out.println("Ошибка ввода");
                }
            }

        control = 0;
        while (control==0) {
            System.out.print("Введите position LABORER, DEVELOPER, LEAD_DEVELOPER, COOK, CLEANER: \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"view\" содержит null");
                } else {
                    position = Position.valueOf(result.toUpperCase());
                    control++;
                }
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка ввода: поле \"position\" не содержит значение из указанного списка");
            }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите status HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION: \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"status\" содержит null");
                } else {
                    status = Status.valueOf(result.toUpperCase());
                    control++;
                }
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка ввода: поле \"status\" не содержит значение из указанного списка");
            }
        }

        System.out.println ("Введите Organization ");

        control = 0;
        while (control==0) {
            System.out.print("Введите full name: \n");
            result = reader.readLine();
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                System.out.println("Ошибка ввода: поле \"fullName\" содержит null");
            } else { fullName = result; control++; }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите employees count \n");
            try {
                result = reader.readLine();
                employeesCount = Integer.parseInt(result);
                if (employeesCount <= 0) {
                    System.out.println("Ошибка ввода: поле \"employeesCount\" не является целым положительным числом");
                } else control++;
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода: поле \"employeesCount\" не является целым числом");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите organization type PUBLIC, TRUST, PRIVATE_LIMITED_COMPANY \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    type = OrganizationType.EMPTY;
                } else {
                    type = OrganizationType.valueOf(result.toUpperCase());
                    control++;
                    organization = new Organization(fullName, employeesCount, type);
                }
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка ввода: поле \"type\" не содержит значение из указанного списка");
            }
        }

        if (name != null && x != null && y != null &&
                salary != -1 && position != null && status != null &&
                fullName != null && employeesCount != 0 && type != null) {
            this.name = name; this.salary = salary; this.endDate = endDate; this.x = x; this.y = y;
            this.position = position; this.status = status; this.fullName = fullName;
            this.employeesCount = employeesCount; this.type = type; this.x = x; this.y = y;
            this.creationDate = creationDate;
        }

        return 1;
    }

    public String toStrings() {
        return "update " + id + " (name - "+name+"; coordinates: ( "+x+"; "+y+" ); creationDate "+creationDate+"; salary - "+salary+"; " +
                "endDate  "+endDate+"; position - "+position+"; status - "+status+"; " +
                "Organization: fullName - "+fullName+", employeesCount - "+employeesCount+", organizationType: "+type+" )";

    }


    public String toStringsNoArguments() {
        return "update " + id;

    }
}
