package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.util.Vector;

public class Filter_contains_name implements Serializable {
    private transient Vector<Worker> workers;
    private String containsName;
    private String info;


    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers) {
        this.workers = workers;
    }

    public Filter_contains_name (Vector<Worker> workers, String containsName) {
        this.workers = workers;
        this.containsName = containsName;
    }

    public Filter_contains_name(String containsName) {
        this.containsName = containsName;
    }

    public Filter_contains_name() {}

    static Vector <Worker> sortVector ( Vector<Worker> vector){
        for (int i =0; i < vector.size(); i++){
            for(int j = i + 1; j <= vector.size() - 1; j++){
                if (vector.get(i).getId() > vector.get(j).getId()){
                    Worker tmp = vector.get(j);
                    vector.set(j, vector.get(i));
                    vector.set(i, tmp);
                }
            }
        }
        return  vector;
    }

    public void execute() {
        info = "";
        sortVector(workers);
        workers.stream().filter(f -> f.getName().contains(containsName)).forEach(s -> info = info + s);
        if (info=="") info = "Элементы не найдены";
    }

    public String toStrings() {
        return "Filter_contains_name " + containsName;
    }
}

