package Commands;

import Classes.Worker;
import Instruments.DBHandler;

import java.io.Serializable;
import java.util.Vector;

public class Remove_lower implements Serializable {
    private transient Vector<Worker> workers;
    private Long id;
    private String info;
    private transient DBHandler db;
    private String creater;

    public Remove_lower() {
        this.info = null;
    }

    public Remove_lower(Vector<Worker> workers, Long id) {
        this.workers = workers;
        this.id = id;
    }

    public Remove_lower(Vector<Worker> workers, Long id, DBHandler db) {
        this.workers = workers;
        this.id = id;
        this.db = db;
    }

    public void setUserId(String creater) {
        this.creater = creater;
    }

    public Remove_lower(Long id) {
        this.id = id;
    }

    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers, DBHandler db) {
        this.workers = workers;
        this.db = db;
    }

    public void execute() {
        int rows = db.executeUpdate("DELETE FROM workers WHERE id <"+id+" and creater = '"+ creater+"'");
        workers.clear();
        db.getData(workers, "SELECT * FROM workers;");
        workers = null;
        info = "Количесвто удалённых элементов:" + (rows) ;
    }

    public String toStrings() {
        return "remove_lower "+ id;
    }
}
