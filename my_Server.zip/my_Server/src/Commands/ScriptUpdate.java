package Commands;

import Classes.*;
import Instruments.DBHandler;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Vector;

public class ScriptUpdate implements Serializable {

    private transient Vector<Worker> workers;
    private transient Worker worker;
    private Integer elementId;
    private transient ArrayList<String> scriptCommands;
    private int i;
    private String info;
    private DBHandler db;
    private String creater;

    public ScriptUpdate (Vector<Worker> workers, Integer elementId, ArrayList<String> scriptCommands, int i) {
        this.workers = workers;
        this.elementId = elementId;
        this.scriptCommands = scriptCommands;
        this.i = i;
    }

    public ScriptUpdate (Vector<Worker> workers, Integer elementId, ArrayList<String> scriptCommands, int i, DBHandler db) {
        this.workers = workers;
        this.elementId = elementId;
        this.scriptCommands = scriptCommands;
        this.i = i;
        this.db = db;
    }

    public void setUserId (String creater) {
        this.creater = creater;
    }

    public String getInfo() {
        return this.info;
    }

    public void execute() {
    }

    public int fieldsUpdate() {
        int control = 0;
        if (workers != null) {
            for (Worker f : workers) {
                if (f.getId().toString().equalsIgnoreCase(elementId.toString())) {
                    control = 1;
                    worker = f;
                    break;
                }
            }
        }
        if (control == 0) { info = "Ошибка ввода: элемента с данным id не существует в коллекции"; return 0; }
        else {
            String result;
            Long id;
            String name = null;
            Coordinates coordinates;
            Double x = null;
            Float y = null;
            java.time.LocalDate creationDate = LocalDate.now();
            int salary = -1;
            java.time.LocalDateTime endDate;
            Position position = null;
            Status status = null;
            Organization organization;
            String fullName = null;
            int employeesCount = -1;
            OrganizationType type = null;
            String creater = null;

            id = workers.lastElement().getId()+1;
            Long idCopy = id;
            if (workers != null) {
                Long con2 = id;
                while (control==0) {
                    for (Worker f : workers) {
                        if (f.getId() == idCopy) {
                            id++;
                        }
                    }
                    if (con2 == id) control++;
                    else con2 = id;
                }
            }

            result = scriptCommands.get(i+1);
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                info = "Ошибка ввода: поле \"name\" содержит null";
                return 0;
            } else if (result.equalsIgnoreCase("")) {
                info = "Ошибка ввода: поле \"name\" не может быть пустым";
                return 0;
            }
            else if (result.equalsIgnoreCase("-")) { name = worker.getName(); }
            else name = result;

            result = scriptCommands.get(i+2);
            try {
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"salary\" не может быть null";
                    return 0;}
                else {
                    salary = Integer.parseInt(result);
                    if (salary <= 0) {
                        info = "Ошибка ввода: поле \"salary\" должно быть больше 0";
                        return 0;
                    }
                }
            } catch(NumberFormatException e){
                info = "Ошибка: поле \"salary\" должно быть целым числом";
                return 0;
            }

            result = scriptCommands.get(i+3) + scriptCommands.get(i+4);
            try {
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { endDate = null; }
                endDate = LocalDateTime.parse(result, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
            } catch (NumberFormatException e) {
                info = "Ошибка. Поле \"endDate\" введено неверно (верный формат: dd:MM:yy HH:mm:ss";
                return 0;
            }

            result = scriptCommands.get(i+4);
            try {
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"x\" не может быть null"; return 0; }
                x = Double.parseDouble(result);
            } catch (NumberFormatException e) {
                info = "Ошибка: поле \"x\" не является целым числом";
                return 0;
            }

            result = scriptCommands.get(i+5);
            try {
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"y\" не может быть null"; return 0; }
                y = Float.parseFloat(result);
                if (y>77) { info = "Ошибка. Поле \"y\" должно быть меньше 77"; return 0; }
            } catch (NumberFormatException e) {
                info = "Ошибка. Поле \"y\" не является целым числом";
                return 0;
            }

            result = scriptCommands.get(i+6);
            try {
                position = Position.valueOf(result);
            }catch(IllegalArgumentException e){
                System.out.println("Ошибка: поле введено неверно");
                return 0;
            }

            result = scriptCommands.get(i+7);
            try { status = Status.valueOf(result);
            }catch(IllegalArgumentException e){
                System.out.println("Ошибка: поле введено неверно");
                return 0;
            }

            result = scriptCommands.get(i+8);
            try {
                if(result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"fullName\" не может быть null"; return 0; }
                fullName = result;
            }catch(Exception e){
                return 0;
            }

            result = scriptCommands.get(i+9);
            try {
                if(result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"employeesCount\" не может быть null"; return 0; }
                employeesCount = Integer.parseInt(result);
                if(employeesCount<0){info = "Ошибка: поле employeesCount не может быть меньше "; return 0;}
            }catch(Exception e){
                System.out.println("Ошибка: поле employeesCount должно быть больше 0");
                return 0;
            }

            result = scriptCommands.get(i+10);
            try {
                if(result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"organizationType\" не может быть null"; return 0; }
                type = OrganizationType.valueOf(result);
            }catch(IllegalArgumentException e){
                System.out.println("Ошибка: поле введено неверно");
                return 0;
            }

            if (db.executeUpdate("UPDATE workers SET \"orgEmpCount\"= '"+employeesCount+"', \"name\" = '"+name+"'," +
                    " \"orgFullName\" = '"+fullName+"', " + "status = '"+status+"', \"position\" = '"+position+"'," +
                    " \"organizationType\" = "+type+", " + "\"corX\" = '"+x+"', \"corY\" = "+y+", " +
                    "salary = "+salary+", cd_day = "+creationDate.getDayOfMonth()+", cd_month = "+creationDate.getMonthValue()+", " +
                    "cd_year = "+creationDate.getYear()%100+", ed_day ="+endDate.getDayOfMonth()+", ed_month = "+endDate.getMonthValue()+
                    ", ed_year = "+endDate.getYear()%100+", creater = "+creater+", ed_hour = "+endDate.getHour()+
                    ", ed_min = "+endDate.getMinute()+", ed_sec = "+endDate.getSecond()+" WHERE id = "+id) == -1) {
                return 1;
            }
            else {
                workers.clear();
                db.getData(workers, "SELECT * FROM flats;");
                info = "Элемент обновлен";
                workers = null;
                worker = null;
            }
            return 1;
        }
    }
}
