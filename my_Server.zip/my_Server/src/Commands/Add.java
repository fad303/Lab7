package Commands;

import Classes.*;
import Instruments.DBHandler;

import java.time.format.DateTimeFormatter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Vector;
import java.time.LocalDateTime;

public class Add implements Serializable {

    private transient Vector<Worker> workers;
    private transient Worker worker;
    private String info;
    private String name;
    private int salary;
    private LocalDateTime endDate;
    private Double x;
    private Float y;
    private Coordinates coordinates;
    private Position position;
    private Status status;
    private Organization organization;
    private String fullName;
    private long employeesCount;
    private OrganizationType type;
    private Long id;
    private LocalDate creationDate = LocalDate.now();
    private transient DBHandler db;
    private String creater;

    public Add() { this.info = null; }

    public Add (Vector<Worker> workers) {
        this.workers = workers;
        this.info = null;
    }

    public Add (Vector<Worker> workers,  DBHandler db) {
        this.workers = workers;
        this.db = db;
        this.info = null;
    }

    public void setUserId(String userId) {
        this.creater = userId;
    }


    public void setWorkers(Vector<Worker> workers,  DBHandler db) {
        this.workers = workers;
        this.db = db;
    }

    public String getInfo() {
        return this.info;
    }

    public void execute() {
        String command;
        command = "INSERT INTO workers (\"orgEmpCount\", name, \"orgFullName\", status, \"position\", \"organizationType\", " +
                "\"corX\", \"corY\", salary, cd_day, cd_month, cd_year, ed_day, ed_month, ed_year, creater, ed_hour, ed_min, ed_sec) "+
                "values ("+employeesCount+", '"+name+"', '"+fullName+"', '"+status+"', '"+
                position+"', '"+type+"', "+x+", "+y+", "+salary+", "+creationDate.getDayOfMonth()+", "+
                creationDate.getMonthValue()+", "+ creationDate.getYear()%100+", "+endDate.getDayOfMonth()+", "+
                endDate.getMonthValue()+", "+endDate.getYear()%100+", '"+creater+"',"+endDate.getHour()+", "+endDate.getMinute()+", "+
                endDate.getSecond()+")";

        if (db.executeUpdate(command) == 0) {
            info = "Сбой создания элемента";
        }
        else {
            workers.clear();
            db.getData(workers, "SELECT * FROM workers;");
            info = "Элемент создан";
            workers = null;
            worker = null;
        }

    }

    public int fields() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String result;
        long id = 0L;
        String name = null;
        LocalDateTime endDate = null;
        Double x = 0.0D;
        Float y = 0.0F;
        Coordinates coordinates = null;
        Position position = null;
        Status status = null;
        Organization organization = null;
        String fullName = null;
        int employeesCount = 0;
        OrganizationType type = null;
        LocalDate creationDate = LocalDate.now();


        int control = 0;
        while (control==0) {
            System.out.print("Введите Name ");
            result = reader.readLine();
            if (result.equalsIgnoreCase("null")) {
                System.out.println("Ошибка ввода: поле \"name\" содержит null");
            } else if (result.equalsIgnoreCase("")) {
                System.out.println("Ошибка ввода: поле \"name\" не может быть пустым");
            } else { name = result; control++; }
        }

        control = 0;
        while (control==0){
            System.out.println("Введите end date");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    endDate = null;
                } else {
                    endDate = LocalDateTime.parse(result, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
                    control++;
                }
            }catch(Exception e){
                System.out.println("Поле endDate введено некорректно (dd.MM.yy HH:mm:ss)");
            }
        }


        control = 0;
        while (control==0) {
            System.out.print("Введите salary \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"salary\" содержит null");
                } else {
                    salary = Integer.parseInt(result);
                    if (salary <= 0) {
                        System.out.println("Ошибка ввода: поле \"salary\" должно быть больше 0");
                    }
                    else control++;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода: поле \"salary\" должно быть числом ");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }

        System.out.println ("Coordinates:");

        control = 0;
        while (control==0) {
            System.out.print("Введите x \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"x\" содержит null");
                } else {
                    x = Double.parseDouble(result);
                    control++;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода: поле \"x\" не является целым числом");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите y: \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"y\" содержит null");
                } else {
                    y = Float.parseFloat(result);
                    if (y >= 77) {
                    System.out.println("Ошибка ввода: поле \"y\" должно быть меньше 77");
                    } else {
                            control++;
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода: поле \"y\" является числом");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }

        coordinates = new Coordinates(x, y);

        control = 0;
        while (control==0) {
            System.out.print("Введите position: LABORER, DEVELOPER, LEAD_DEVELOPER, COOK, CLEANER \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"position\" содержит null");
                } else {
                    position = Position.valueOf(result.toUpperCase());
                    control++;
                }
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка ввода: поле \"position\" не содержит значение из указанного списка");
            }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите status: HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    System.out.println("Ошибка ввода: поле \"status\" содержит null");
                }else{
                    status = Status.valueOf(result.toUpperCase());
                    control++;
                }
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка ввода: поле \"status\" не содержит значение из указанного списка");
            }
        }

        System.out.println ("Введите Organization ");

        control = 0;
        while (control==0) {
            System.out.print("Введите full name: \n");
            result = reader.readLine();
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                System.out.println("Ошибка ввода: поле \"fullName\" содержит null");
            } else { fullName = result; control++; }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите employees count \n");
            try {
                result = reader.readLine();
                employeesCount = Integer.parseInt(result);
                if (employeesCount <= 0) {
                    System.out.println("Ошибка ввода: поле \"employeesCount\" не является целым положительным числом");
                } else control++;
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода: поле \"employeesCount\" не является целым числом");
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            }
        }

        control = 0;
        while (control==0) {
            System.out.print("Введите organization type: PUBLIC, TRUST, PRIVATE_LIMITED_COMPANY \n");
            try {
                result = reader.readLine();
                if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) {
                    type = OrganizationType.EMPTY;
                } else {
                    type = OrganizationType.valueOf(result.toUpperCase());
                    control++;
                    organization = new Organization(fullName, employeesCount, type);
                }
            } catch (IOException e) {
                System.out.println("Ошибка ввода");
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка ввода: поле \"type\" не содержит значение из указанного списка");
            }
        }


        if (name != null && x != null && y != null &&
                salary != -1 && position != null && status != null &&
                fullName != null && employeesCount != 0 && type != null) {
            this.name = name; this.salary = salary; this.endDate = endDate; this.x = x; this.y = y;
            this.position = position; this.status = status; this.fullName = fullName;
            this.employeesCount = employeesCount; this.type = type;
            this.creationDate = creationDate; this.id = id;
        }

        return 1;
    }

    public String toStrings() {
        return "add [id = "+id+"; name = "+name+"; coordinates = (x: "+x+"; y:"+y+"); creationDate = "+creationDate+"; " +
                "salar =: "+salary+"; endDate = "+endDate+"; position = "+position+"; " +
                "status = "+status+"; Organization: fullName = "+fullName+"; employeesCount = "+employeesCount+"; " +
                "organizationType = "+type+"]";

    }

}
