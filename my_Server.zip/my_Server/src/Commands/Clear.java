package Commands;

import Classes.Worker;
import Instruments.DBHandler;

import java.io.Serializable;
import java.util.Vector;

public class Clear implements Serializable {
    private transient Vector<Worker> workers;
    private String info;
    private transient DBHandler db;
    private String creater;

    public Clear() { info=null; }

    public Clear (Vector<Worker> workers) {
        info = null;
        this.workers = workers;
    }

    public Clear (Vector<Worker> workers, DBHandler db) {
        info = null;
        this.workers = workers;
        this.db = db;
    }

    public void setWorkers(Vector<Worker> workers, DBHandler db){
        this.workers = workers;
        this.db = db;
    }

    public void setUserId(String creater) {
        this.creater = creater;
    }

    public void execute() {
        String command ="DELETE FROM workers WHERE creater = '"+creater+"'";
        if (db.executeUpdate(command) == 0) {
            info = "Не удалось очистить коллекцию creater = " +creater;
        } else {
            workers.clear();
            db.getData(workers, "SELECT * FROM workers;");
            info = "Коллекция успешно очищена от ваших объектов";
            workers = null;
        }
    }

    public String getInfo() {
        return info;
    }

    @Override
    public String toString() {
        return "clear";
    }
}
