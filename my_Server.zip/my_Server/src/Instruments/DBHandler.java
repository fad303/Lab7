package Instruments;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Vector;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import Classes.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBHandler {
    private static final String user = "s285669";
    private static final String pwd = "efi930";
    private static final String driver = "org.postgresql.Driver";
    private static final String dbHost = "pg";
    private static final String dbPort = "5432";
    private static final String dbName = "studs";
    private static final String url = "jdbc:postgresql://"+dbHost+":"+dbPort+"/"+dbName;
    private Connection con;
    static final Logger logger = LoggerFactory.getLogger(DBHandler.class);

    public void getConnection () {

        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            logger.info("Не удалось подключить драйвер");
            e.printStackTrace();
        }
        logger.info("Драйвер подключен");

        try {
            con = DriverManager.getConnection(url, user, pwd);
        } catch (SQLException throwables) {
            logger.info("Не удалось установить соединение с БД");
            throwables.printStackTrace();
        }
        logger.info("Установлено соединение с " + dbName);

    }

    public synchronized ResultSet executeQuery (String query) {
        Statement stmt;
        ResultSet rs;
        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery(query);
        } catch (SQLException throwables) {
            logger.info("Не удалось выполнить запрос");
            throwables.printStackTrace();
            return null;
        } finally {
        }
        logger.info("Запрос выполнен");

        return rs;
    }

    public synchronized int executeUpdate (String query) {
        Statement stmt;
        int rows;
        try {
            stmt = con.createStatement();
            rows = stmt.executeUpdate(query);
        } catch (SQLException throwables) {
            logger.info("Не удалось выполнить запрос");
            throwables.printStackTrace();
            return 0;
        }
        logger.info("Запрос выполнен");

        return rows;
    }

    public synchronized void getData (Vector<Worker> workers, String query) {
        ResultSet rs = executeQuery(query);
        try {
            while (rs.next()) {
                workers.add(new Worker(Long.parseLong(rs.getString(17)), rs.getString(2),
                        new Coordinates(rs.getDouble(7), rs.getFloat(8)),
                        LocalDate.of(rs.getInt(12), rs.getInt(11), rs.getInt(10)), rs.getInt(9),
                        LocalDateTime.of(rs.getInt(15), rs.getInt(14), rs.getInt(13), rs.getInt(18), rs.getInt(19), rs.getInt(20)),
                        Position.valueOf(rs.getString(5).toUpperCase()), Status.valueOf(rs.getString(4).toUpperCase()),
                        new Organization(rs.getString(3), Long.parseLong(rs.getString(1)), OrganizationType.valueOf(rs.getString(6).toUpperCase())), rs.getString(16)));
            }
        } catch (Exception throwables) {
            logger.info("Не удалось прочитать данные");
            throwables.printStackTrace();
        }
    }
}
