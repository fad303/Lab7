package Instruments;

import Classes.*;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Vector;

import Commands.Execute_Script;

public abstract class Processing {

    public static int commands (String userCommand, String OriginalUC) {
        if ((userCommand.length() == 6 && userCommand.equalsIgnoreCase("update")) ||
                (userCommand.length() == 7 && userCommand.equalsIgnoreCase("update "))) {
            System.out.println("Для команды update необходимо указать id  ");
            return 0;
        }
        else if ((userCommand.length() > 7 && userCommand.contains("update "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                System.out.println("Для команды update необходимо указать id нового элемента коллекции ");
                return 0;
            }
            else {
                try {
                    Long id = Long.parseLong((parts[1]));
                    if (id <= 0) {
                        System.out.println("Id элемента должен быть больше 0");
                        return 0;
                    }
                } catch (NumberFormatException ex) {
                    System.out.println("Элемента с данным id не существует (поле id должно быть целым числом)");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 12 && userCommand.equalsIgnoreCase("remove_by_id")) ||
                (userCommand.length() == 13 && userCommand.equalsIgnoreCase("remove_by_id "))) {
            System.out.println("Для команды remove_by_id необходимо указать id элемента ");
            return 0;
        }

        else if ((userCommand.length() > 13 && userCommand.contains("remove_by_id "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                System.out.println("Для команды \"remove_by_id\" необходимо указать только id элемента ");
                return 0;
            }
            else {
                try {
                    long id = Long.parseLong((parts[1]));
                    if (id <= 0) {
                        System.out.println("Id элемента коллекции должен быть целым положительным числом");
                        return 0;
                    }
                } catch (Exception e) {
                    System.out.println("Id элемента коллекции должен быть числом");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 14 && userCommand.equalsIgnoreCase("execute_script")) ||
                (userCommand.length() == 15 && userCommand.equalsIgnoreCase("execute_script "))) {
            System.out.println("Необходимо указать имя файла при вводе команды");
            return 0;
        }

        else if ((userCommand.length() > 15 && userCommand.contains("execute_script "))) {
            String[] parts = OriginalUC.split(" ",3);
            if (parts.length != 2) {
                System.out.println("Необходимо ввести только имя файла");
                return 0;
            }
            else {
                File file = new File(parts[1]);
                if (! file.exists()) {
                    System.out.println("Файл не найден");
                    return 0;
                }
            }
        }
        else if ((userCommand.length() == 12 && userCommand.equalsIgnoreCase("remove_lower")) ||
                (userCommand.length() == 13 && userCommand.equalsIgnoreCase("remove_lower "))) {
            System.out.println("При вводе команды необходимо указать номер элемента коллекции ");
            return 0;
        }

        else if ((userCommand.length() > 13 && userCommand.contains("remove_lower "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                System.out.println("При вводе команды необходимо указать только номер элемента коллекции ");
                return 0;
            }
            else {
                try {
                    int id = Integer.parseInt(parts[1]);
                    if (id<=0) { System.out.println("Номер эелемента должен быть положительным числом"); return 0; }
                }
                catch (Exception e) {
                    System.out.println("Номер эелемента должен быть числом");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 16 && userCommand.equalsIgnoreCase("filter_by_status")) ||
                (userCommand.length() == 17 && userCommand.equalsIgnoreCase("filter_by_status "))) {
            System.out.println("При вводе команды необходимо указать status: HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION");
            return 0;
        }

        else if ((userCommand.length() > 17 && userCommand.contains("filter_by_status "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                System.out.println("При вводе команды необходимо указать только status");
                return 0;
            }
            else {
                try {
                    Status status = Status.valueOf(parts[1].toUpperCase());
                    if(parts[1].equals("") || parts[1]==null){
                        System.out.println("Необходимо ввести status: HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION");
                        return 0;
                    }
                } catch (Exception e) {
                    System.out.println("Необходимо ввести существующий status: HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 20 && userCommand.equalsIgnoreCase("filter_contains_name")) ||
                (userCommand.length() == 21 && userCommand.equalsIgnoreCase("filter_contains_name "))) {
            System.out.println("При вводе команды необходимо указать name");
            return 0;
        }

        else if ((userCommand.length() > 21 && userCommand.contains("filter_contains_name "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                System.out.println("При вводе команды необходимо указать только name");
                return 0;
            }
            else {
                try {
                    String name = parts[1];
                    if (name.equals("")) {
                        System.out.println("Значение поля name не должно быть пустым");
                        return 0;
                    }
                } catch (Exception e) {
                    System.out.println("Значение поля name введено некорректно");
                    return 0;
                }
            }
        }

        else {
            try {
                Commands command = Commands.valueOf(userCommand);
            }
            catch (IllegalArgumentException NullPointerException){
                System.out.println("Введённой команды не существует. Для просмотра списка команд введите \"help\".");
                return 0;
            }
        }
        return 1;
    }

    public static ArrayList<String> scriptToString (File script, ArrayList<String> scripts) {
        ArrayList<String> result = new ArrayList<>();
        try {
            FileReader fr = new FileReader(script);
            BufferedReader reader = new BufferedReader(fr);
            String line; String[] parts;
            while (( line = reader.readLine()) != null) {
                parts = line.split(" ");
                if (!parts[0].equalsIgnoreCase("execute_script")) {
                    result.add(line);
                } else {
                    for (int i = 0; i<scripts.size(); i++) {
                        if (scripts.get(i).equalsIgnoreCase(parts[1])) {
                            System.out.println("Ошибка: обнаружена рекурсия.");
                            return result;
                        }
                    }
                    scripts.add(parts[1]);
                    Execute_Script es = new Execute_Script(parts[1]);
                    es.setScripts(scripts);
                    es.getCommandsFromFile();
                    for (int i = 0; i<es.getScriptCommands().size(); i++) {
                        result.add(es.getScriptCommands().get(i));
                    }
                }
            }
            fr.close();
            reader.close();
        }
        catch (FileNotFoundException e) {
            System.out.println("Выбранный файл не обнаружен");
            return result;
        }
        catch (IOException e) {
            System.out.println("Ошибка чтения файла");
            return result;
        }
        return result;
    }

    public static String getFilePath(String variable) {
        String path = System.getenv(variable);
        if (path == null) {
            return "";
        }
        else return path;
    }
}
