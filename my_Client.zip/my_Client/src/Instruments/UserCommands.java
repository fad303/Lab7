package Instruments;

import Classes.Status;
import Classes.Worker;
import Commands.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Vector;

public abstract class UserCommands {

    protected static int status;
    public static void execute(String userCommand, BufferedReader reader, Vector<Worker> workers, LocalDateTime today, File file, ArrayList<String> history, ArrayList<String> scripts) throws IOException {      // Выполняет команду, если status == 1
        if (Instruments.UserCommands.status == 1){
            switch(userCommand.toLowerCase()) {
                case ("help"):
                    Help help = new Help();
                    help.execute();
                    break;
                case ("exit"):
                    Save saveExit = new Save (workers, file);
                    saveExit.execute();
                    Exit exit = new Exit (reader);
                    exit.execute();
                    break;
                case ("show"):
                    Show show = new Show(workers);
                    show.execute();
                    break;
                case ("info"):
                    Info info = new Info(workers, today);
                    info.execute();
                    break;
                case ("add"):
                    Add add = new Add(workers);
                    if (add.fields()==1) {
                        add.execute();
                    }
                    else System.out.println("Ошибка при создании элемента коллекции");
                    break;
                case ("clear"):
                    Clear clear = new Clear(workers);
                    clear.execute();
                    break;
                case ("save"):
                    Save save = new Save (workers, file);
                    save.execute();
                    break;
                case ("history"):
                    History his = new History(history);
                    his.execute();
                    break;
                case ("print_ascending"):
                    Print_Ascending pr = new Print_Ascending(workers);
                    pr.execute();
                    break;
            }
            try {
                if (userCommand.substring(0, 6).equalsIgnoreCase("update")) {
                    String[] parts = userCommand.split(" ", 2);
                    Long id = 0L; int control = 1;
                    try {
                        id = Long.parseLong(parts[1]);
                    }
                    catch (Exception e) {
                        control = 0;
                    }
                    if (control != 0) {
                        Update update = new Update(workers, id);
                        if (update.fieldsUpdate() == 1) System.out.println("Элемент обновлен");
                        else System.out.println("Ошибка обновления элемента");
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 12).equalsIgnoreCase("remove_by_id")) {
                    String[] parts = userCommand.split(" ", 2);
                    Long id = 0L; int control = 1;
                    try {
                        id = Long.parseLong(parts[1]);
                    }
                    catch (Exception e) {
                    }
                    if (control != 0) {
                        Remove_By_Id rbi = new Remove_By_Id(workers, id);
                        rbi.execute();
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 14).equalsIgnoreCase("execute_script")) {
                    String[] parts = userCommand.split(" ", 2);
                    Execute_Script es = new Execute_Script(parts[1], workers, history, today, reader, file, scripts);
                    es.execute();
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 12).equalsIgnoreCase("remove_lower")) {
                    String[] parts = userCommand.split(" ", 2);
                    Long id = Long.parseLong(parts[1]);
                    Remove_lower rl = new Remove_lower(workers, id);
                    rl.execute();
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 16).equalsIgnoreCase("Filter_by_status")) {
                    String[] parts = userCommand.split(" ", 2);
                    Status status = Status.valueOf(parts[1].toUpperCase());
                    Filter_by_status fbs = new Filter_by_status(workers, status);
                    fbs.execute();
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 20).equalsIgnoreCase("Filter_contains_name")) {
                    String[] parts = userCommand.split(" ", 2);
                    String containsName = parts[1];
                    Filter_contains_name fcn = new Filter_contains_name(workers, containsName);
                    fcn.execute();
                }
            }
            catch (Exception e) {
            }
        }
    }
}
