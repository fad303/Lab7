package Instruments;

import Classes.*;


import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.Vector;

public class Reader {

    public static String parse_row(String Row, String Tag){
        String tmp = Row.replaceAll("<"+Tag+">", "").trim();
        tmp = tmp.replaceAll("</"+Tag+">", "");
        return tmp;
    }

    public static Vector<Worker> readFile(File file) throws FileNotFoundException{
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yy");
            DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss");

            Vector<Worker> workers = new Vector<>();
            Long id = 0L;
            String name = "";
            String empty = "";
            Coordinates coordinates = new Coordinates(0, 0);
            double x = 0.0D;
            float y = 0.0F;
            java.time.LocalDate creationDate = LocalDate.parse("01.01.20", formatter);
            int salary = 0;
            java.time.LocalDateTime endDate = LocalDateTime.parse("01.01.20 00:00:00", formatter2);
            Position position = null;
            Status status = null;
            Organization organization = new Organization("AAA", 0, OrganizationType.PUBLIC); //Organization
            String fullName = null;
            Long employeesCount = 0L;
            OrganizationType type = null;
            String creater="";
        boolean chk = true;

            try (Scanner sc = new Scanner(new File(String.valueOf("savedWorkers.xml")))) {//C:б/project/
                while (sc.hasNext()) {

                    boolean bln = true;
                    String holder0 = sc.nextLine();
                    String tr0 = holder0.trim();
                    if (tr0.startsWith("<Worker>")) {
                        String holder = sc.nextLine();
                        String tr = holder.trim();
                        while (!(tr.startsWith("</Worker>"))){

                            if (tr.startsWith("<id>")) {
                                id = Long.parseLong(parse_row(tr, "id"));
                                for (int i = 0; i < workers.size(); i++){
                                    if (workers.elementAt(i).getId() == id){
                                        System.out.println("id не может повторятся");
                                    }
                                }if(id < 0){
                                    System.out.println("Id должно быть больше 0");
                                }
                            }
                            if (tr.startsWith("<name>")) {
                                name = parse_row(tr, "name");
                                if (name.equals(empty)){
                                    System.out.println("Name не может быть пустым");
                                }
                            }

                            if (tr.startsWith("<coordinates>")) {
                                try {
                                    x = Double.parseDouble(parse_row(sc.nextLine(), "x"));
                                    while (bln) {
                                        y = Float.parseFloat(parse_row(sc.nextLine(), "y"));
                                        coordinates = new Coordinates(x,y);
                                        if (y < 77) {
                                            bln = false;
                                        } else {
                                            System.out.println("максимальное значение y: 77");
                                        }
                                    }
                                } catch (NumberFormatException nre) {
                                    System.out.println("Coordinates должны быть числом");
                                }

                            }
                            try {
                                if (tr.startsWith("<creationDate>")) {
                                    creationDate = LocalDate.parse(parse_row(tr, "creationDate"), formatter);
                                }
                            }catch(Exception e){
                                System.out.println("CreationDate введено некорректно ");
                            }

                            if (tr.startsWith("<salary>")) {
                                try {
                                    salary = Integer.parseInt(parse_row(tr, "salary"));
                                    if (salary < 0){
                                        System.out.println("Salary не может быть меньше 0");
                                    }
                                }catch(Exception e){
                                    System.out.println("Salary должно бвть целым числом");
                                }
                            }

                            try {
                                if (tr.startsWith("<endDate>")) {
                                    endDate = LocalDateTime.parse(parse_row(tr, "endDate"), formatter2);
                                }
                            }catch(Exception e){
                                System.out.println("endDate введено некорректно");
                            }

                            if (tr.startsWith("<position>")) {
                                try {
                                    position = Position.valueOf(parse_row(tr, "position").toUpperCase().trim());
                                }catch(Exception e){
                                    System.out.println("Position введено некорректно");
                                }
                            }
                            if (tr.startsWith("<status>")) {
                                try {
                                    status = Status.valueOf(parse_row(tr, "status").toUpperCase().trim());
                                }catch(Exception e){
                                    System.out.println("Status введено некорректно");
                                }
                            }
                            if (tr.startsWith("<organization>")) {
                                try {
                                    fullName = parse_row(sc.nextLine(), "fullName");
                                    if(fullName==""){
                                        System.out.println("Organization должно быть заполнено");
                                    }
                                    employeesCount = Long.parseLong(parse_row(sc.nextLine(), "employeesCount"));
                                    if(employeesCount>0) {
                                        type = OrganizationType.valueOf(parse_row(sc.nextLine(), "type").toUpperCase().trim());
                                    }else{
                                        System.out.println("employeesCount должно быть больше 0");
                                    }
                                }catch(Exception e){
                                    System.out.println("Coordinates введены некорректно");
                                }
                                organization = new Organization(fullName, employeesCount, type);
                            }
                            holder = sc.nextLine();
                            tr = holder.trim();
                        }
                        workers.add(new Worker(id, name, coordinates, creationDate, salary, endDate, position, status, organization, creater));
                    }
                }
                chk = false;
            } catch (Exception e) {
                System.out.println("Файл не найден"+e);
            }
            return workers;
    }

}
