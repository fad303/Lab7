package Commands;

public interface ExecutableC {
    public String execute();
}
