package Commands;

import Classes.*;
import Instruments.DBHandler;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Vector;

public class ScriptAdd implements Serializable {
    private transient Vector<Worker> workers;
    private transient Worker worker;
    private int i;
    private transient ArrayList<String> scriptCommands;
    private String info;
    private transient DBHandler db;
    private String creater;

    public ScriptAdd (Vector<Worker> workers, ArrayList<String> scriptCommands, int i) {
        this.workers = workers;
        this.scriptCommands = scriptCommands;
        this.i = i;
    }

    public ScriptAdd (Vector<Worker> workers, ArrayList<String> scriptCommands, int i, DBHandler db) {
        this.workers = workers;
        this.scriptCommands = scriptCommands;
        this.i = i;
        this.db = db;
    }

    public void setUserId (String creater) {
        this.creater = creater;
    }

    public String getInfo() {
        return this.info;
    }

    public int fields() {
        Long id;
        String name = null;
        Coordinates coordinates;
        Double x = null;
        Float y = null;
        java.time.LocalDate creationDate = LocalDate.now();
        int salary = -1;
        java.time.LocalDateTime endDate;
        Position position = null;
        Status status = null;
        Organization organization;
        String fullName = null;
        int employeesCount = -1;
        OrganizationType type = null;
        String creater = "";

        String result;

        int control = 0;


        if(workers.size()!=0) {
            id = workers.lastElement().getId() + 1;
        }else{
            id =1L;
        }

        result = scriptCommands.get(i+1);
        if (result.equalsIgnoreCase("null")) { info = "Ошибка: поле \"name\" не может быть null"; return 0; }
        else if (result.equalsIgnoreCase("")) { info = "Ошибка: поле \"name\" не может быть пустым"; return 0; }
        else name = result;

        result = scriptCommands.get(i+2);
        try {
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"salary\" не может быть null";
                return 0;}
            else {
                salary = Integer.parseInt(result);
                if (salary <= 0) {
                    info = "Ошибка ввода: поле \"salary\" должно быть больше 0";
                    return 0;
                }
            }
        } catch(NumberFormatException e){
            info = "Ошибка: поле \"salary\" должно быть целым числом";
            return 0;
        }

        result = scriptCommands.get(i+3);
        try {
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { endDate = null; }
           endDate = LocalDateTime.parse(result, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
        } catch (NumberFormatException e) {
            info = "Ошибка. Поле \"endDate\" введено неверно (верный формат: dd:MM:yy HH:mm:ss";
            return 0;
        }

        result = scriptCommands.get(i+4);
        try {
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"x\" не может быть null"; return 0; }
            x = Double.parseDouble(result);
        } catch (NumberFormatException e) {
            info = "Ошибка: поле \"x\" не является целым числом";
            return 0;
        }

        result = scriptCommands.get(i+5);
        try {
            if (result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"y\" не может быть null"; return 0; }
            y = Float.parseFloat(result);
            if (y>77) { info = "Ощибка. Поле \"y\" должно быть меньше 77"; return 0; }
        } catch (NumberFormatException e) {
            info = "Ощибка. Поле \"y\" не является целым числом";
            return 0;
        }

        result = scriptCommands.get(i+6);
        try {
            position = Position.valueOf(result);
        }catch(IllegalArgumentException e){
            System.out.println("Ошибка: поле введено неверно");
            return 0;
        }

        result = scriptCommands.get(i+7);
        try { status = Status.valueOf(result);
        }catch(IllegalArgumentException e){
            System.out.println("Ошибка: поле введено неверно");
            return 0;
        }

        result = scriptCommands.get(i+8);
        try {
            if(result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"fullName\" не может быть null"; return 0; }
            fullName = result;
        }catch(Exception e){
            return 0;
        }

        result = scriptCommands.get(i+9);
        try {
            if(result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"employeesCount\" не может быть null"; return 0; }
            employeesCount = Integer.parseInt(result);
            if(employeesCount<0){info = "Ошибка: поле employeesCount не может быть меньше "; return 0;}
        }catch(Exception e){
            System.out.println("Ошибка: поле employeesCount должно быть больше 0");
            return 0;
        }

        result = scriptCommands.get(i+10);
        try {
            if(result.equalsIgnoreCase("null") || result.equalsIgnoreCase("")) { info = "Ошибка: поле \"organizationType\" не может быть null"; return 0; }
            type = OrganizationType.valueOf(result);
        }catch(IllegalArgumentException e){
            System.out.println("Ошибка: поле введено неверно");
            return 0;
        }
        if (endDate==null) {
            if (id != null && name != null && x != null && y != null && salary != -1 &&
                    position != null && status != null && type != null &&
                    employeesCount != -1 && fullName != null) {
                worker = new Worker(id, name, new Coordinates(x, y), creationDate, salary, endDate, position, status, new Organization(fullName, employeesCount, type),creater);
            }
        }
        else {
            if (id != null && name != null && x != null && y != null && salary != -1 &&
                    position != null && status != null && fullName != null && employeesCount != -1 &&
                    type != null) {
                worker = new Worker(id, name, new Coordinates(x, y), creationDate, salary, endDate, position, status, new Organization(fullName, employeesCount, type), creater);
            }
        }
        return 1;
    }

    public void execute(){
        String command;
        command = "INSERT INTO workers (\"orgEmpCount\", name, \"orgFullName\", status, \"position\", \"organizationType\"," +
                " \"corX\", \"corY\", salary, cd_day, cd_month, cd_year, ed_day, ed_month, ed_year, creater, id, ed_hour, ed_min, ed_sec) "+
                "values ("+worker.organization.getEmployeesCount()+", '"+worker.getName()+"', '"+worker.organization.getFullName()+"', '"+
                worker.getStatus()+"', '"+worker.getPosition()+"', '"+worker.organization.getType()+"', "+worker.getCoordinates().getX()+
                ", "+worker.getCoordinates().getY()+", "+worker.getSalary()+", "+worker.getCreationDate().getDayOfMonth()+", "+
                worker.getCreationDate().getMonthValue()+", "+worker.getCreationDate().getYear()%100+
                ", "+worker.getEndDate().getDayOfMonth()+", "+worker.getEndDate().getMonthValue()+
                ", "+worker.getEndDate().getYear()%100+", '"+worker.getUserId()+"', "+worker.getId()+", "+
                worker.getEndDate().getHour()+", "+worker.getEndDate().getMinute()+", "+worker.getEndDate().getSecond()+")";

        if (db.executeUpdate(command) == 0) {
            info = "Сбой создания элемента";
        }
        else {
            workers.clear();
            db.getData(workers, "SELECT * FROM workers;");
            info = "Элемент создан";
            workers = null;
            worker = null;
        }
        //"orgEmpCount", name, "orgFullName", status, "position", "organizationType", "corX", "corY",
        // salary, cd_day, cd_month, cd_year, ed_day, ed_month, ed_year, creater, id

        //workers.add(worker);
        //info = "Элемент создан";
    }
}
