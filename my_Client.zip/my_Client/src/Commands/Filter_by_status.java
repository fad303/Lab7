package Commands;

import Classes.Worker;
import Classes.Status;

import java.io.Serializable;
import java.util.Vector;

public class Filter_by_status implements Serializable {
    private transient Vector<Worker> workers;
    private Status status;
    private String info;

    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers) {
        this.workers = workers;
    }

    public Filter_by_status (Vector<Worker> workers, Status status) {
        this.workers = workers;
        this.status = status;
    }

    public Filter_by_status(Status status) {
        this.status = status;
    }

    public Filter_by_status() {}

    static Vector <Worker> sortVector ( Vector<Worker> vector){
        for (int i =0; i < vector.size(); i++){
            for(int j = i + 1; j <= vector.size() - 1; j++){
                if (vector.get(i).getId() > vector.get(j).getId()){
                    Worker tmp = vector.get(j);
                    vector.set(j, vector.get(i));
                    vector.set(i, tmp);
                }
            }
        }
        return  vector;
    }

    public void execute() {
        info = "";
        sortVector(workers);
        workers.stream().filter(f -> f.getStatus() == status).forEach(s -> info = info + s + "\n");
        if (info=="") info = "Элементы не найдены";
    }

    public String toStrings() {
        return "filter_by_status " + status;
    }
}
