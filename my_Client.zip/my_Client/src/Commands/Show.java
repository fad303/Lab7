package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.util.Vector;

public class Show implements Serializable {
    private transient Vector<Worker> workers;
    private String info;

    public Show() { info = null; }

    public Show (Vector<Worker> workers) {
        this.workers = workers;
        info = null;
    }

    public String getInfo() {
        return info;
    }

    static Vector <Worker> sortVector ( Vector<Worker> vector){
        for (int i =0; i < vector.size(); i++){
            for(int j = i + 1; j <= vector.size() - 1; j++){
                if (vector.get(i).getId() > vector.get(j).getId()){
                    Worker tmp = vector.get(j);
                    vector.set(j, vector.get(i));
                    vector.set(i, tmp);
                }
            }
        }
        return  vector;
    }

    public void execute() {
        info = "";
        if (workers.size() != 0) {
            sortVector(workers);
            workers.stream().forEach(s -> info = info + s + "\n");
            int a;
        }
        else
            info = "Коллекция пуста";
        workers = null;
    }

    @Override
    public String toString() {
        return "show";
    }

}
