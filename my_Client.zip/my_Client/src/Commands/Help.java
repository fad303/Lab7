package Commands;

import Instruments.Processing;
import java.io.Serializable;

public class Help implements Serializable {
    private String info;

    public String getInfo() {
        return this.info;
    }

    public Help () {}
        public void execute() {
            info="help : справка по доступным командам \n" +
                    "info : информация о коллекции \n" +
                    "show : все елементов коллекции \n" +
                    "add {element} : добавить новый элемент \n" +
                    "update id {element} : обновить значение элемента, заданного по id\n" +
                    "remove_by_id id : удалить элемент коллекции по id\n" +
                    "clear : очистить коллекцию\n" +
                    "save : сохранить коллекцию в файл\n" +
                    "execute_script file_name : исполнить скрипт из указанного файла\n" +
                    "exit : завершить программу\n" +
                    "remove_lower {element} : удалить из коллекции все элементы, меньшие, чем заданный id\n" +
                    "history : последние 11 команд\n" +
                    "filter_by_status status : элементы, значение поля status которых равно заданному\n" +
                    "filter_contains_name name : элементы, значение поля name которых содержит заданную подстроку\n" +
                    "print_ascending : элементы коллекции в порядке возрастания";
    }

    @Override
    public String toString() {
        return "help";
    }
}
