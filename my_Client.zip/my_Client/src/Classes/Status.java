package Classes;

import java.io.Serializable;

public enum Status implements Serializable {
    HIRED,
    RECOMMENDED_FOR_PROMOTION,
    REGULAR,
    PROBATION;
}