package ClientApp;

import Classes.Status;
import Commands.*;
import Instruments.Processing;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;

public class ClientUserCommands {
    protected static int status;               // 1-команда введена верно, 0-неверно

    public static void check (String userCommand) {       //Определяет status
        ClientUserCommands.status = Processing.commands (userCommand.toLowerCase(), userCommand);
    }

    public static Object getCommand(String userCommand, BufferedReader reader, String userId) throws IOException {      // Выполняет команду, если status == 1
        if (ClientUserCommands.status == 1){
            switch(userCommand.toLowerCase()) {
                case ("help"):
                    Help help = new Help();
                    return help;
                case ("exit"):
                    reader.close();
                    System.out.println("Работа завешрена");
                    System.exit(0);
                case ("show"):
                    Show show = new Show();
                    return show;
                case ("info"):
                    Info info = new Info();
                    return info;
                case ("add"):
                    Add add = new Add();
                    add.setUserId(userId);
                    add.fields();
                    return add;
                case ("clear"):
                    Clear clear = new Clear();
                    clear.setUserId(userId);
                    return clear;
                case ("history"):
                    History his = new History(ProcessingAnswer.getHistory());
                    return his;
                case ("print_ascending"):
                    Print_Ascending pr = new Print_Ascending();
                    return pr;
            }
            try {
                if (userCommand.substring(0, 6).equalsIgnoreCase("update")) {
                    String[] parts = userCommand.split(" ", 2);
                    Long id = 0L; int control = 1;
                    try {
                        id = Long.parseLong(parts[1]);
                    }
                    catch (Exception e) {
                        control = 0;
                    }
                    if (control != 0) {
                        Update update = new Update(id);
                        update.setUserId(userId);
                        return update;
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 12).equalsIgnoreCase("remove_by_id")) {
                    String[] parts = userCommand.split(" ", 2);
                    Integer id = 0; int control = 1;
                    try {
                        id = Integer.parseInt(parts[1]);
                        if (id<=0) {
                            System.out.println("Ошибка: id должно быть больше 0");
                            control = 0;
                        }
                    }
                    catch (Exception e) {
                        System.out.println("Ошибка: id должно быть целым числом");
                        control = 0;
                    }
                    if (control != 0) {
                        Remove_By_Id rbi = new Remove_By_Id(id);
                        rbi.setUserId(userId);
                        return rbi;
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 14).equalsIgnoreCase("execute_script")) {
                    String[] parts = userCommand.split(" ", 2);
                    Execute_Script es = new Execute_Script(parts[1], ProcessingAnswer.getHistory());
                    es.setUserId(userId);
                    ArrayList<String> scripts = new ArrayList<>(); scripts.add(parts[1]);
                    es.setScripts(scripts);
                    es.getCommandsFromFile();
                    return es;
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 12).equalsIgnoreCase("remove_lower")) {
                    String[] parts = userCommand.split(" ", 2); int control = 1;
                    try {
                        Long id = Long.parseLong(parts[1]);
                        if (id<=0) {
                            System.out.println("Ошибка: id должно быть положительным");
                            control = 0;
                        }
                        if (control != 0) {
                            Remove_lower rl = new Remove_lower(id);
                            rl.setUserId(userId);
                            return rl;
                        }
                    } catch (Exception e) {
                        System.out.println("Ошибка: id должно быть числом");
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 16).equalsIgnoreCase("filter_by_status")) {
                    String[] parts = userCommand.split(" ", 2);
                    Status status = Status.valueOf(parts[1].toUpperCase());
                    Filter_by_status fbs = new Filter_by_status(status);
                    return fbs;
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 20).equalsIgnoreCase("filter_contains_name")) {
                    String[] parts = userCommand.split(" ", 2);
                    String containsName = parts[1];
                    Filter_contains_name fcn = new Filter_contains_name(containsName);
                    return fcn;
                }
            }
            catch (Exception e) {
            }
        }
        return null;
    }

    public static int getStatus () {
        return status;
    }
}
